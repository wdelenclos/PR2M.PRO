var template = {
    debut: 'Démarrage dans 5 secondes',
    telecharger: 'Télécharger la fiche du test',
    fin: 'Test terminé'
}

